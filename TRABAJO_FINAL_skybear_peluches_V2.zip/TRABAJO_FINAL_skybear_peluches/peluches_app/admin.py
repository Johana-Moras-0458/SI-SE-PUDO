from django.contrib import admin
from .models import Peluche
# Register your models here.

admin.site.register(Peluche)
