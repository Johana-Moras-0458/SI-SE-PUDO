from django.apps import AppConfig


class PeluchesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'peluches_app'
