from django.apps import AppConfig


class ProveedorAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'proveedor_app'
